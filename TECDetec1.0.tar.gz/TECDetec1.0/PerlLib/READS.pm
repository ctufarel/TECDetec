package READS;

use strict;
use warnings;

sub discardRead(){

	my ($ref_discard_read, $in_f, $out_f) = @_;
	my %discard_read = %$ref_discard_read;

	open (IN, $in_f) or die "Cannot open $in_f!\n";
	open (OUT, ">$out_f") or die "Cannot write $out_f!\n";

	# Printing control. print if print = 1
	my $print = 0;

	# line_state = 0 first line, 1 second line ...
	my $line_state = 0;

	while (<IN>){

		# discard empty lines.
		next if (/^\s*$/);

		if ($line_state == 0){
			/^.([A-Za-z0-9_.:-]+).*$/;
			
			unless ($discard_read{$1}){
				$print = 1;
				print OUT $_;
			}else{
				$print = 0;
			}

		}else{
			if ($print){
				print OUT $_;
			}
		}
		
		$line_state ++;

		# In standard fastq file, each sequence has 4 lines.
		# 	- Line 1 begins with a '@' character and is followed by a sequence identifier and an optional description (like a FASTA title line).
		# 	- Line 2 is the raw sequence letters.
		#	- Line 3 begins with a '+' character and is optionally followed by the same sequence identifier (and any description) again.
		#	- Line 4 encodes the quality values for the sequence in Line 2, and must contain the same number of symbols as letters in the sequence.

		$line_state %= 4;

	}

	close IN;
	close OUT;

	return;
}

sub getRead(){

	my ($ref_get_read, $in_f, $out_f) = @_;
	my %get_read = %$ref_get_read;

	open (IN, $in_f) or die "Cannot open $in_f!\n";
	open (OUT, ">$out_f") or die "Cannot write $out_f!\n";

	# Printing control. print if print = 1
	my $print = 0;

	# line_state = 0 first line, 1 second line ...
	my $line_state = 0;

	while (<IN>){

		# discard empty lines.
		next if (/^\s*$/);

		if ($line_state == 0){
			/^.([A-Za-z0-9_.:-]+).*$/;
			
			if ($get_read{$1}){
				$print = 1;
				print OUT $_;
			}else{
				$print = 0;
			}

		}else{
			if ($print){
				print OUT $_;
			}
		}
		
		$line_state ++;

		$line_state %= 4;
	}

	close IN;
	close OUT;

	return;
}

1;