package ASSEMBLE;

use strict;
use warnings;

use SAM_reader;
use SAM_entry;

sub extract_frag_coords {
    my ($sam_file, $frag_coords_file, $transfrag_size_min, $transfrag_size_max) = @_;
   
    print STDERR "-extracting read coordinates from $sam_file into $frag_coords_file\n\n";
    
    my $sam_reader = new SAM_reader($sam_file);
    my %sam_info = ();
    my %frag_coords = ();
    my $num_key = 0;
    
    while ($sam_reader->has_next()){
        
        my $sam_entry = $sam_reader->get_next();

        my $rname = $sam_entry->get_rname();
        my $core_qname = $sam_entry->get_core_qname();
        my $pair_side = ($sam_entry->is_first_in_pair()) ? 1 : 2;        
        my ($read_start, $read_end) = $sam_entry->get_genome_span();

        if ($rname ne '*' && $read_start && $read_end){
            push @{$sam_info{$core_qname}}, [$rname, $pair_side, $read_start, $read_end];
        }
    }
  
    foreach my $read (sort keys %sam_info){

        $num_key++;

        if ($#{$sam_info{$read}} == 1){
            
            my ($rname_A, $pair_side_A, $read_start_A, $read_end_A) = @{$sam_info{$read}[0]};
            my ($rname_B, $pair_side_B, $read_start_B, $read_end_B) = @{$sam_info{$read}[1]};

            if ($rname_A eq $rname_B 
                && $pair_side_A ne $pair_side_B 
                && $pair_side_A =~ /\d/ 
                && $pair_side_B =~ /\d/){

                my @coords = sort {$a <=> $b} ($read_start_A, $read_start_B, $read_end_A, $read_end_B);
                my $min = shift @coords;
                my $max = pop @coords;

                my $transfrag_size = $max - $min + 1;
                if ($transfrag_size >= $transfrag_size_min && $transfrag_size <= $transfrag_size_max){
                    @{$frag_coords{$num_key}} = ($read, $rname_A, $min, $max);
                }else{  # treat as unpairly mapped reads
                    @{$frag_coords{$num_key}} = ($read . "/$pair_side_A", $rname_A, $read_start_A, $read_end_A);
                    $num_key++;
                    @{$frag_coords{$num_key}} = ($read . "/$pair_side_B", $rname_B, $read_start_B, $read_end_B);
                }
            }else{
                @{$frag_coords{$num_key}} = ($read . "/$pair_side_A", $rname_A, $read_start_A, $read_end_A);
                $num_key++;
                @{$frag_coords{$num_key}} = ($read . "/$pair_side_B", $rname_B, $read_start_B, $read_end_B);
            }

        }elsif ($#{$sam_info{$read}} == 0){ # not pairly mapped

            my ($rname, $pair_side, $read_start, $read_end) = @{$sam_info{$read}[0]};
            @{$frag_coords{$num_key}} = ($read . "/$pair_side", $rname, $read_start, $read_end);
        }
    }

    open (my $fh_out, ">$frag_coords_file") or die "Error, cannot write to file $frag_coords_file";

    foreach my $key (map {$_->[0]}
                     sort { ($a->[1] cmp $b->[1])
                            ||
                            ($a->[2] <=> $b->[2])
                            ||
                            ($a->[3] <=> $b->[3])
                    } map {[$_, $frag_coords{$_}[1]=~/^chr(.+)$/, $frag_coords{$_}[2], $frag_coords{$_}[3]]
                    } keys %frag_coords){
        print $fh_out join("\t", @{$frag_coords{$key}}) . "\n";
    }

    close $fh_out;

    return;    
}

sub write_frag_coverage {

    my ($frag_coords_file, $frag_coverage_file) = @_;

    my %coverage = ();

    open (my $fh, $frag_coords_file) or die "Error, cannot open file $frag_coords_file";
    open (my $fh_out, ">$frag_coverage_file") or die "Cannot write file $frag_coverage_file";

    my $current_chr = "";
    my $counter = 0;

    while (my $line = <$fh>){
        
        chomp $line;
        $counter++;

        my ($frag_name, $chr, $lend, $rend) = split /\t/, $line;

        #if ($counter % 1000 == 0){

            #print STDERR "\r[$counter lines read]  chr:$chr  start:$lend  end:$rend   ";            
        #}

        if (%coverage && $chr ne $current_chr){
            &report_coverage(\%coverage, $fh_out);
            %coverage = ();
        }

        $current_chr = $chr;
        &add_coverage($current_chr, [$lend, $rend], \%coverage);
    }

    if (%coverage){
        &report_coverage(\%coverage, $fh_out);
    }

    close $fh;
    close $fh_out;

    return;
}

sub add_coverage {

    my ($chr, $ref_coords, $ref_coverage) = @_;
    
    my ($lend, $rend) = @$ref_coords;
    
    ## add coverage:
    for (my $i = $lend; $i <= $rend; $i++) {
        $ref_coverage->{$chr}->[$i]++;
    }
    return;
}

sub report_coverage {
    my ($ref_coverage, $out_file) = @_;
    
    ## output the coverage information:
    foreach my $chr (sort keys %$ref_coverage) {
        
        next unless (defined($chr) && $chr =~ /\w/);
        
        print $out_file "TECDetec chrom=$chr\n";
        
        my @coverage = @{$ref_coverage->{$chr}};
        
        my $last_cov = 0;

        for (my $i = 1; $i <= $#coverage; $i++) {
            my $cov = $coverage[$i] || 0;
            
            if ($cov || $last_cov){
                print $out_file "$i\t$cov\n";
            }
            $last_cov = $cov;
        }      
    }    
    return;
}

sub define_coverage_partitions {

    my ($wig_file, $partitions_file) = @_;

    my %part = ();

    open (my $fh, $wig_file) or die "Cannot open file $wig_file";
    open (my $fh_out, ">$partitions_file") or die "Cannot write $partitions_file";

    my $chr = "";
    my $lend = undef;
    my $rend = undef;

    my $count = 0;
    my $sum_cov = 0;
    my $total_cov = 0;
    my $total_len = 0;

    while (<$fh>){
        chomp;

        if (/TECDetec chrom=(\S+)/){

            if ($lend && $rend){

                my $ave_cov = $sum_cov/($rend - $lend + 1);

                $count++;
                my $id = "p_$count";
                push @{$part{$chr}}, {id => $id,
                                      lend => $lend,
                                      rend => $rend,
                                      cov => $sum_cov,
                                      ave => $ave_cov,};
                print $fh_out "$id\t$chr\t$lend\t$rend\t$sum_cov\t$ave_cov\n";
                $total_cov += $sum_cov;
                $total_len += ($rend - $lend + 1);

                $lend = undef;
                $rend = undef;
                $sum_cov = 0;
            }

            $chr = $1;
            next;
        }

        my ($pos, $cov) = split /\t/;

        if ($cov){
            if (! defined $lend){
                $lend = $pos;
                $rend = $pos;
            }else{
                $rend = $pos;
            }
            $sum_cov += $cov;
        }else{
            # no coverage
            if ($lend){

                my $ave_cov = $sum_cov/($rend - $lend + 1);

                $count++;
                my $id = "p_$count";
                push @{$part{$chr}}, {id => $id,
                                      lend => $lend,
                                      rend => $rend,
                                      cov => $sum_cov,
                                      ave => $ave_cov,};
                print $fh_out "$id\t$chr\t$lend\t$rend\t$sum_cov\t$ave_cov\n";
                $total_cov += $sum_cov;
                $total_len += ($rend - $lend + 1);

                $lend = undef;
                $rend = undef;
                $sum_cov = 0;
            }
        }
    }

    # last block
    if ($lend && $rend) {

        my $ave_cov = $sum_cov/($rend - $lend + 1);
        
        $count++;
        my $id = "p_$count";
        push @{$part{$chr}}, {id => $id,
                              lend => $lend,
                              rend => $rend,
                              cov => $sum_cov,
                              ave => $ave_cov,};
        print $fh_out "$id\t$chr\t$lend\t$rend\t$sum_cov\t$ave_cov\n";
        $total_cov += $sum_cov;
        $total_len += ($rend - $lend + 1);
    }

    close $fh;
    close $fh_out;

    my $total_ave = $total_cov/$total_len;

    print STDERR "Average coverage: $total_ave\n";

    return(\%part, $total_ave);
}

sub extract_reads_per_coverage_partition {

    my ($frag_coverage_file, $partitions_file, $sam_file, $partition_track_file, $min_cov) = @_;

    my ($ref_partitions, $total_ave) = &define_coverage_partitions($frag_coverage_file, $partitions_file);

    if ($min_cov == 0){
        $min_cov = $total_ave;
    }

    my %partitions = %$ref_partitions;

    print STDERR "\nminimum average coverage is $min_cov\n";

    open (my $track_fh, ">$partition_track_file") or die $!;

    my @ordered_partitions;
    my $current_partition = undef;

    my $read_counter = 0;

    my @reads = ();

    my $current_chr = "";

    my $sam_reader = new SAM_reader($sam_file);

    while (my $sam_entry = $sam_reader->get_next()){
        my $chr = $sam_entry->get_rname();
        next if $chr eq '*';

        my $read_name = $sam_entry->get_read_name();
        my $start = $sam_entry->get_pos();

        if (! exists $partitions{$chr}){
            print STDERR "-warning, no read partitions defined for $chr\n";
            next;
        }

        my $new_partition_flag = 0;

        if ($chr ne $current_chr){

            @ordered_partitions = @{$partitions{$chr}};
            
            $new_partition_flag = 1;

        }elsif (defined($current_partition)){
            if ($current_chr && $start > $current_partition->{rend}){

                $new_partition_flag = 1;
            }
        }else{
            last;
        }

        if ($new_partition_flag){

            if (defined($current_partition) && $current_partition->{ave} >= $min_cov){

                print $track_fh join("\t", ($current_partition->{id}, $current_chr, $current_partition->{lend}, $current_partition->{rend}, $current_partition->{cov}, $read_counter, @reads)) . "\n";
                $current_partition = shift @ordered_partitions;
                $current_chr = $chr;
            }else{
                $current_partition = shift @ordered_partitions;
                $current_chr = $chr;
            }

            @reads = ();
            $read_counter = 0;
        }

        if (defined($current_partition) && $start >= $current_partition->{lend} && $start <= $current_partition->{rend}) {

            push @reads, $read_name;

            $read_counter++;
        }
    }
    
    if ($current_partition->{ave} >= $min_cov){
        print $track_fh join("\t", ($current_partition->{id}, $current_chr, $current_partition->{lend}, $current_partition->{rend}, $current_partition->{cov}, $read_counter, @reads)) . "\n";
    }

    close $track_fh;

    return;
}

sub merge_partition {

    my ($partition_track_file, $merged_partition_file, $min_intron_length, $unique_sam_info, $junc_info_file) = @_;

    my %trans = ();
    my $trans_count = 0;
    my $current_chr = "";
    my $current_start = undef;
    my $current_end = undef;
    my $sum_cov = "";
    my $sum_length = "";
    my $sum_reads = "";
    my $total_reads = "";
    my @readnames = ();
    my %junc_map;
    my $from_te;
    my $refte = "";

    open (my $fh_info, $unique_sam_info) or die "Cannot open $unique_sam_info";

    my @line = <$fh_info>;
    my @info = split /\t/, $line[0];
    chomp $info[1];
    $total_reads = $info[1];
    
    close $fh_info;

    open (my $fh_junc, $junc_info_file) or die "Cannot open $junc_info_file";

    while (my $l = <$fh_junc>){
        chomp $l;
        my @e = split /\t/, $l;
        @{$junc_map{$e[0]}} = ($e[1],$e[2]);
    }

    close $fh_junc;

    open (my $fh, $partition_track_file) or die "Error: cannot open $partition_track_file\n";
    open (my $fh_out, ">$merged_partition_file") or die "Error: cannot write $merged_partition_file";

    while (my $l = <$fh>){

        chomp $l;
        my ($id, $chr, $start, $end, $cov, $read_counter, @reads) = split /\t/, $l;

        unless ($current_chr){
            $current_chr = $chr;
            $current_start = $start;
            $current_end = $end;
            $sum_length = $end - $start + 1;
            $sum_cov = $cov;
            $sum_reads = $read_counter;
            @readnames = @reads;
            $from_te = 1;
            next;
        }

        if ($current_chr ne $chr){
            $trans_count++;
            my $ave_cov = $sum_cov / $sum_length;
            my $fpkm = &calcu_fpkm($sum_reads, $sum_length, $total_reads);
            my $start_bed = $current_start - 1;
            my $end_bed = $current_end - 1;
            my @te = ();
            my %seen = ();
            foreach my $rn (@readnames){
                $rn =~ s/\/\d$//;
                unless ($junc_map{$rn}[0]){
                    $from_te = 0;
                }
                push @te, $junc_map{$rn}[1] if ($junc_map{$rn}[1]);
            }
            my @unique_te = grep {!$seen{$_}++} @te;
            $refte = join ("/", @unique_te);
            print $fh_out join("\t", ($trans_count, $current_chr, $start_bed, $end_bed, $ave_cov, $fpkm, $from_te, $refte)) . "\n";
            $current_start = $start;
            $current_end = $end;
            $sum_length = $end - $start + 1;
            $sum_cov = $cov;
            $sum_reads = $read_counter;
            $current_chr = $chr;
            @readnames = @reads;
            $from_te = 1;
            $refte = "";
        }elsif ($start - $current_end > $min_intron_length){
            $trans_count++;
            my $ave_cov = $sum_cov / $sum_length;
            my $fpkm = &calcu_fpkm($sum_reads, $sum_length, $total_reads);
            my $start_bed = $current_start - 1;
            my $end_bed = $current_end - 1;
            my @te = ();
            my %seen = ();
            foreach my $rn (@readnames){
                $rn =~ s/\/\d$//;
                unless ($junc_map{$rn}[0]){
                    $from_te = 0;
                }
                push @te, $junc_map{$rn}[1] if ($junc_map{$rn}[1]);
            }
            my @unique_te = grep {!$seen{$_}++} @te;
            $refte = join ("/", @unique_te);
            print $fh_out join("\t", ($trans_count, $current_chr, $start_bed, $end_bed, $ave_cov, $fpkm, $from_te, $refte)) . "\n";
            $current_start = $start;
            $current_end = $end;
            $sum_length = $end - $start + 1;
            $sum_cov = $cov;
            $sum_reads = $read_counter;
            @readnames = @reads;
            $from_te = 1;
            $refte = "";
        }else{
            $current_end = $end;
            $sum_length += ($end - $start + 1);
            $sum_cov += $cov;
            $sum_reads += $read_counter;
            push @readnames, @reads;
        }
    }

    $trans_count++;
    my $ave_cov = $sum_cov / $sum_length;
    my $fpkm = &calcu_fpkm($sum_reads, $sum_length, $total_reads);
    my $start_bed = $current_start - 1;
    my $end_bed = $current_end - 1;
    my @te = ();
    my %seen = ();
    foreach my $rn (@readnames){
        $rn =~ s/\/\d$//;
        unless ($junc_map{$rn}[0]){
            $from_te = 0;
        }
        push @te, $junc_map{$rn}[1] if ($junc_map{$rn}[1]);
    }
    my @unique_te = grep {!$seen{$_}++} @te;
    $refte = join ("/", @unique_te);
    print $fh_out join("\t", ($trans_count, $current_chr, $start_bed, $end_bed, $ave_cov, $fpkm, $from_te, $refte)) . "\n";

    close $fh;
    close $fh_out;
}

sub calcu_fpkm {

    my ($mapped, $length, $total) = @_;

    my $fpkm = $mapped * (10^9) / ($length * $total);

    return $fpkm;
}

1;