package SAM_entry;

use strict;
use warnings;
use Carp;

sub new {
	my $class = shift;
	my ($line) = @_;

	unless (defined $line) {
		confess "Error, need sam text line as parameter";
	}

	chomp $line;

	my @fields = split(/\t/, $line);
	
	my $self = {
		_fields => [@fields],
	};
	
	bless ($self, $class);
	
	return($self);
}


####
sub get_fields {
	my $self = shift;
	return (@{$self->{_fields}});
}

sub get_line {
	my $self = shift;
	my @fields = @{$self->{_fields}};

	return(join("\t", @fields));
}

####
sub get_qname {
	my $self = shift;
	return ($self->{_fields}->[0]);
}

sub get_core_qname {
	my $self = shift;
	my $qname = $self->get_qname();
	my $core_qname = $qname;

	$core_qname =~ s|/\d$||;
	
	return($core_qname);
}

####
sub get_read_name {
	my $self = shift;

	my $read_name = $self->get_qname();

	if ($self->is_first_in_pair()) {
		$read_name .= "/1";
	}
	elsif ($self->is_second_in_pair()) {
		$read_name .= "/2";
	}

	return($read_name);
}


####
sub get_rname {
	my $self = shift;
	return($self->{_fields}->[2]);
}

####
sub get_pos {
	my $self = shift;
	return($self->{_fields}->[3]); # left most position
}

####
sub get_cigar {
	my $self = shift;
	return($self->{_fields}->[5]);
}

###################

# get alignment coordinates of reference and query
# reference: @genome_coords - elements: [start_pos, end_pos] [start_pos, end_pos] ...;
# query: @query_coords - elements: [start_pos, end_pos] [start_pos, end_pos] ... 

sub get_alignment_coords {
	my $self = shift;

	my $genome_left = $self->get_pos();
	my $cigar = $self->get_cigar();

	my @genome_coords;
	my @query_coords;

	my $query_left = 0;
	$genome_left--;

	while ($cigar =~ /(\d+)([MIDNSHPX=])/g){
		my $len = $1;
		my $op = $2;

		if ($op eq 'M'){	# alignment match (can be a sequence match or mismatch)			
			my $genome_right = $genome_left + $len;
			my $query_right = $query_left + $len;

			push (@genome_coords, [$genome_left+1, $genome_right]);
			push (@query_coords, [$query_left+1, $query_right]);

			# reset coord pointers
			$genome_left = $genome_right;
			$query_left = $query_right;
		}elsif ($op eq 'D' || $op eq 'N'){	# deletion or skipped region from the reference
			$genome_left += $len;
		}elsif ($op eq 'I' || $op eq 'S' || $op eq 'H'){ # insertion to the reference, gap in reference
			$query_left += $len;
		}
	}
	return(\@genome_coords, \@query_coords);
}

sub get_genome_span {
	my $self = shift;
	my ($ref_genome_coords, $ref_query_coords) = $self->get_alignment_coords();

	my @coords;
	foreach my $coordset (@$ref_genome_coords){
		push (@coords, @$coordset);
	}

	@coords = sort {$a <=> $b} @coords;

	my $min_coord = shift @coords;
	my $max_coord = pop @coords;

	return ($min_coord, $max_coord);
}

###################

sub get_mate_rname {
	my $self = shift;
   
	return($self->{_fields}->[6]);
}

####
sub get_mate_pos {
	my $self = shift;

	return($self->{_fields}->[7]);
}

####
sub get_mapping_quality {
	my $self = shift;
	return($self->{_fields}->[4]);
}


####
sub get_sequence {
	my $self = shift;
	return($self->{_fields}->[9]);
}

####
sub get_quality_scores {
	my $self = shift;
	return($self->{_fields}->[10]);
}


####
sub get_inferred_insert_size {
    my $self = shift;
    
    # should probably check to see if it's a paired read or not...  user beware
    return($self->{_fields}->[8]);
}



###################
## Flag Processing
###################

# from sam format spec:

=flag_description

Flag Description
0x0001 the read is paired in sequencing, no matter whether it is mapped in a pair
0x0002 the read is mapped in a proper pair (depends on the protocol, normally inferred during alignment) 1
0x0004 the query sequence itself is unmapped
0x0008 the mate is unmapped 1
0x0010 strand of the query (0 for forward; 1 for reverse strand)
0x0020 strand of the mate 1
0x0040 the read is the first read in a pair 1,2
0x0080 the read is the second read in a pair 1,2
0x0100 the alignment is not primary (a read having split hits may have multiple primary alignment records)
0x0200 the read fails platform/vendor quality checks
0x0400 the read is either a PCR duplicate or an optical duplicate

1. Flag 0x02, 0x08, 0x20, 0x40 and 0x80 are only meaningful when flag 0x01 is present.
2. If in a read pair the information on which read is the first in the pair is lost in the upstream analysis, flag 0x01 shuld
be present and 0x40 and 0x80 are both zero.

=cut


####
sub get_flag {
	my $self = shift;
	my $flag = $self->{_fields}->[1];
	return($flag);
}

sub set_flag {
	my $self = shift;
	my $flag = shift;

	unless (defined $flag) {
		confess "Error, need flag value";
	}

	$self->{_fields}->[1] = $flag;
	return;
}

####
sub is_paired {
	my $self = shift;
	return($self->_get_bit_val(0x0001));
}

sub set_paired {
	my $self = shift;
	my $bit_val = shift;
	
	$self->_set_bit_val(0x0001, $bit_val);
	
	return;
}

####
sub is_proper_pair {
	my $self = shift;
	return($self->_get_bit_val(0x0002));
}

sub set_proper_pair {
	my $self = shift;
	my $bit_val = shift;
	
	$self->_set_bit_val(0x0002, $bit_val);
	return;
}

####
sub is_query_unmapped {
	my $self = shift;
	return($self->_get_bit_val(0x0004));
}

sub set_query_unmapped {
	my $self = shift;
	my $bit_val = shift;

	$self->_set_bit_val(0x0004, $bit_val);
}


####
sub is_mate_unmapped {
	my $self = shift;
	return($self->_get_bit_val(0x0008));
}

sub set_mate_unmapped {
	my $self = shift;
	my $bit_val = shift;
	
	return($self->_set_bit_val(0x0008, $bit_val));
}

####
sub get_query_strand {
	my $self = shift;
	
	my $strand = ($self->_get_bit_val(0x0010)) ? '-' : '+';
	return($strand);
}

####
sub get_query_transcribed_strand{
	my $self = shift;
	my ($lib_type) = @_;

	confess "library type required!" unless ($lib_type);

	my $aligned_strand = $self->get_query_strand();
	my $opposite_strand = ($aligned_strand eq '+') ? '-' : '+';

	my $transcribed_strand;

	unless ($lib_type =~ /^(fr|rf)$/){ # rf: typical of the dUTP/UDG sequencing method
		confess "cannot have $lib_type library type with paired reads";
	}

	if ($self->is_first_in_pair()){
		$transcribed_strand = ($lib_type eq "fr") ? $aligned_strand : $opposite_strand;
	}else{
		$transcribed_strand = ($lib_type eq "fr") ? $opposite_strand : $aligned_strand;
	}

	return($transcribed_strand);
}

######

sub set_query_strand {
	my $self = shift;
	my $strand = shift;

	unless ($strand eq '+' || $strand eq '-') {
		confess "Error, strand value must be [+-]";
	}

	my $bit_val = ($strand eq '+') ? 0 : 1;
	$self->_set_bit_val(0x0010, $bit_val);
}

####
sub get_mate_strand {
	my $self = shift;
	
	my $strand = ($self->_get_bit_val(0x0020)) ? '-' : '+';
	return($strand);
}

sub set_mate_strand {
	my $self = shift;
	my $strand = shift;

	unless ($strand eq '+' || $strand eq '-') {
		confess "Error, strand value must be [+-]";
	}

	my $bit_val = ($strand eq '+') ? 0 : 1;
	$self->_set_bit_val(0x0020, $bit_val);
}

####
sub is_first_in_pair {
	my $self = shift;
	return($self->_get_bit_val(0x0040));
}

sub set_first_in_pair {
	my $self = shift;
	my $bit_val = shift;
	
	$self->_set_bit_val(0x0040, $bit_val);
	return;
}

####
sub is_second_in_pair {
	my $self = shift;
	return($self->_get_bit_val(0x0080));
}


sub set_second_in_pair {
	my $self = shift;
	my $bit_val = shift;

	$self->_set_bit_val(0x0080, $bit_val);
	return;
}



####
sub _get_bit_val {
	my $self = shift;
	my ($bit_position) = @_;

	my $flag = $self->get_flag();
	return($flag & $bit_position);
}


####
sub _set_bit_val {
	my $self = shift;
	my ($bit_position, $bit_val) = @_;

	unless (defined $bit_position && defined $bit_val) {
		confess "Error, need bit position and value";
	}
	
	my $flag = $self->get_flag();

	if ($bit_val) {
		$flag |= $bit_position;
	}
	else {
		# erase bit
		$flag &= ~$bit_position;
	}
	
	$self->set_flag($flag);
}


1; #EOM

