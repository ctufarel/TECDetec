#!/usr/bin/perl

use strict;
use warnings;

use FindBin;
use lib ("$FindBin::Bin/PerlLib");

use SAM_reader;
use SAM_entry;
use READS;
use ASSEMBLE;

use threads;
use Carp;
use Getopt::Long;

BEGIN{

	print "
TECDetec v1.0

Created by Xu Hang in 2014.
Copyright (c) 2014 Xu Hang. All rights reserved.

";
}

# usage
unless (@ARGV){ &usage;}

# parameters initiation

my $cpu_max = 1;
my $insert_size_min = 0;
my $insert_size_max = 500;
my $idx_te = "";
my $idx_mskge = "";
my $idx_ge = "";
my $out_dir = "./tecdetec_out";
my $lib_type = "";
my $min_cov = 1;
my $min_intron_length = 100;
my ($r1, $r2);
my $help = 0;
my $version = "v1.0";
my $version_flag = 0;

# get options

GetOptions ('p|threads=i' => \$cpu_max,
			'I|min=i' => \$insert_size_min,
			'X|max=i' => \$insert_size_max,
			'min_cov=i' => \$min_cov,
			'min_intron=i' => \$min_intron_length,
			'lib_type=s' => \$lib_type,
			'idx_te=s' => \$idx_te,
			'idx_mskge=s' => \$idx_mskge,
			'idx_ge=s' => \$idx_ge,
			'o|out_dir=s' => \$out_dir,
			'r1=s' => \$r1,
			'r2=s' => \$r2,
			'h|help' => \$help,
			'v|version' => \$version_flag,
			) or &usage;


if (@ARGV){
	print "Error: unrecognized parameter!\n";
	&usage;
}

if ($help){&usage;}

if ($version_flag){
	print "TECDetec version: $version\n";
	exit(1);
}

&paramcheck;

my $temp_dir = "$out_dir/temp";

# alignment SAM files
my $sam_align2ge = "$temp_dir/align2ge.sam";
my $sam_align2te_g = "$temp_dir/align2te_global.sam";
my $sam_align2te_l = "$temp_dir/align2te_local.sam";
my $sam_align_subseg2te = "$temp_dir/align_subseg2te.sam";

# output seq files after align2ge
my $out_ge_r1 = "$temp_dir/out_ge_r1.seq";
my $out_ge_r2 = "$temp_dir/out_ge_r2.seq";

# output seq files after align2te_g
my $out_te_g_r1 = "$temp_dir/out_te_g_r1.seq";
my $out_te_g_r2 = "$temp_dir/out_te_g_r2.seq";

# junction seq files
my $junc_r1 = "$temp_dir/junction_r1.seq";
my $junc_r2 = "$temp_dir/junction_r2.seq";

# junction read pairs map to te info file
my $junc_info = "$temp_dir/junc_mapped_end.txt";

# tophat out dir
my $tophat_out = "$temp_dir/tophat_out";

# tophat out bam file
my $tophatout_bam = "$tophat_out/accepted_hits.bam";
my $tophatout_sam = "$temp_dir/tophat_out.sam";

my $unique_sam_info = "$temp_dir/unique.sam.info";
my $unique_plus = "$temp_dir/unique2ge.plus.sam";
my $unique_minus = "$temp_dir/unique2ge.minus.sam";

# output file
my $transcript_file = "$out_dir/tecout.gtf";

# set library-type for tophat
my $library_type = "";
if ($lib_type){
	$library_type = ($lib_type =~ /rf/) ? "fr-firststrand" : "fr-secondstrand";
}else{
	$library_type = "fr-unstranded";
}

main:{

	&check_dir;

	# Align to masked genome (global mapping)
	&align2ge() unless ((-s $sam_align2ge) || (-s "$sam_align2ge.tgz"));

	# Process SAM file, create read pairs that not mapped in a pair in last step for next mapping
	&processSamUnmapped($sam_align2ge, $r1, $r2, $out_ge_r1, $out_ge_r2) unless (((-s $out_ge_r1) || (-s "$out_ge_r1.tgz")) && ((-s $out_ge_r2) || (-s "$out_ge_r2.tgz")));

	# Align to TE assembly (global mapping)
	&align2te_g() unless ((-s $sam_align2te_g) || (-s "$sam_align2te_g.tgz"));	# Global mapping

	# Process SAM file, create read pairs that not mapped in a pair in last step for next mapping
	&processSamUnmapped($sam_align2te_g, $out_ge_r1, $out_ge_r2, $out_te_g_r1, $out_te_g_r2) unless (((-s $out_te_g_r1) || (-s "$out_te_g_r1.tgz"))  && ((-s $out_te_g_r2) || (-s "$out_te_g_r2.tgz")));

	# Align to TE assembly (local mapping)
	&align2te_l() unless ((-s $sam_align2te_l) || (-s "$sam_align2te_l.tgz")); # Local mapping

	# Process SAM file, create read pairs that one read mapped and the other didn't in last step for next mapping
	# Create junc_mapped_end.txt to store which read in a read pair belongs to te
	&processSamMapped($sam_align2te_l) unless (((-s $junc_r1) || (-s "$junc_r1.tgz")) && ((-s $junc_r2) || (-s "$junc_r2.tgz")));

	# Align junction read pairs to reference genome
	&align_junc2ge() unless (-s $tophatout_bam);

	# Get uniquely mapped reads
	&get_unique_sam() unless ((-s $unique_plus) && (-s $unique_minus));

	# Assembler reads to transcripts
	&assemble();

	exit(0);
}

################################
#                              #
#         SUBROUTINES          #
#                              #
################################

sub usage(){

	my $usage = <<_EOUSAGE_;

TECDetec detects transposable elements associated chimeric transcripts.

Usage:
	perl tecdetec.pl [options] -idx_te <TE index> -idx_mskge <masked reference genome index> -idx_ge <reference genome index> -r1 <reads1 file> -r2 <reads2 file>

Options:
	-v/-version
	-p/-threads        <int>        [ default: 1                                                ]
	-lib_type                       [ library type (unstranded if not specified)                ]
	                                [ fr - first read is sequenced in the sense orientation     ]
	                                [ rf - first read is sequenced in the antisense orientation ]
	-I/-min            <int>        [ fragment minimum length                                   ]
	-X/-max            <int>        [ fragment maximum length                                   ]
	-min_cov           <int>        [ minimum coverage fold for detected transcripts            ]
	-min_intron        <int>        [ minimum intron length (default 100bp)                     ]
	-idx_te                         [ bowtie2 index for TE sequences                            ]
	-idx_mskge                      [ bowtie2 index for masked reference genome                 ]
	-idx_ge                         [ bowtie2 index for reference genome                        ]
	-o/-out_dir                     [ output directory (default: ./tecdetec_out)                ]
	-r1                             [ read 1 sequence file                                      ]
	-r2                             [ read 2 sequence file                                      ]

_EOUSAGE_

	;
	print $usage;
	exit(1);
}

sub paramcheck {

	unless ($idx_te){
		print "Error: please specify index for TE sequence assembly using -idx_te\n";
		exit(1);
	}

	unless ($idx_mskge){
		print "Error: please specify index for masked reference genome using -idx_mskge\n";
		exit(1);
	}

	unless ($idx_ge){
		print "Error: please specify index for reference genome using -idx_ge\n";
		exit(1);
	}

	unless ($r1 && $r2){
		print "Error: please provide sequencing datasets\n";
		exit(1);
	}

	if ($lib_type && $lib_type !~ /^(fr|rf)$/){
		print "Error: invalid lib_type\n";
		exit(1);
	}
}

sub check_dir {

	if (-e $out_dir){
		print "\nWARNING: $out_dir exists!\n";
		unless (-e $temp_dir){
			`mkdir $temp_dir`;
		}	
	}else{
		`mkdir $out_dir`;
		`mkdir $temp_dir`;
	}
	return;
}

###############################
#         Run Aligners        #
###############################

sub align2ge {
	
	print STDERR "Align to masked genome (global mapping) ...\n";

	my $cmd_align2ge = "bowtie2 -p $cpu_max -k 1 -I $insert_size_min -X $insert_size_max --fr --no-mixed --end-to-end --very-sensitive -q -x $idx_mskge -1 $r1 -2 $r2 -S $sam_align2ge";
	&process_cmd($cmd_align2ge);

	return;
}

sub align2te_g {
	
	print STDERR "Align to TE assembly (Global mapping) ...\n";

	my $cmd_align2te_g = "bowtie2 -p $cpu_max -k 1 -I $insert_size_min -X $insert_size_max --fr --no-mixed --end-to-end --very-sensitive -q -x $idx_te -1 $out_ge_r1 -2 $out_ge_r2 -S $sam_align2te_g";
	&process_cmd($cmd_align2te_g);

	return;
}

sub align2te_l {
	
	print STDERR "Align to TE assembly (local mapping) ...\n";

	my $cmd_align2te_l = "bowtie2 -p $cpu_max --fr --local --very-sensitive-local -q -x $idx_te -1 $out_te_g_r1 -2 $out_te_g_r2 -S $sam_align2te_l";
	&process_cmd($cmd_align2te_l);
	&compress($out_ge_r1);
	&compress($out_ge_r2);
	&compress($out_te_g_r1);
	&compress($out_te_g_r2);
	return;
}

sub align_junc2ge {

	print STDERR "Align junction reads to reference genome ...\n";

	my $cmd_align_junc2ge = "tophat -p $cpu_max -g 2 --b2-very-sensitive --library-type $library_type -o $tophat_out $idx_ge $junc_r1 $junc_r2";
	&process_cmd($cmd_align_junc2ge);
	&compress($junc_r1);
	&compress($junc_r2);
	return;
}

################################
#       process SAM file       #
################################

sub processSamUnmapped(){

	my ($sam,$read_1_f,$read_2_f,$out_1_f,$out_2_f) = @_;

	my $num_mapped = 0;

	# %mapped_read_id: read_id => 1
	# Stores ids of reads that properly mapped to reference.
	# Reads that not properly mapped will then be aligned in next step.
	my %mapped_read_id = ();

	my $sam_reader = new SAM_reader($sam);

	# Read SAM file
	while ($sam_reader->has_next()){

		my $sam_entry = $sam_reader->get_next();

		next unless ($sam_entry->is_paired());
		next if ($sam_entry->is_query_unmapped());
		next if ($sam_entry->is_mate_unmapped());

		my $qname = $sam_entry->get_qname();

		# get read ids that mapped in a pair (concordant or discordant alignment)
		$num_mapped++;
		$mapped_read_id{$qname} = 1;	
	}

	print STDERR "$num_mapped pairs of reads mapped properly\n";

	my $thread_1 = threads->create('READS::discardRead', \%mapped_read_id, $read_1_f, $out_1_f);
	my $thread_2 = threads->create('READS::discardRead', \%mapped_read_id, $read_2_f, $out_2_f);

	foreach my $thread ($thread_1, $thread_2) {
        $thread->join();
        if (my $error = $thread->error()) {
            print STDERR "Error, thread exited with error $error\n";
        }
    }

    &compress($sam);

    return;
}

sub processSamMapped(){
	my $sam = shift;

	my %junc = ();
	my $num_mapped = 0;

	open (INFO, ">$junc_info") or die "Cannot write $junc_info";

	my $sam_reader = new SAM_reader($sam);

	while ($sam_reader->has_next()){

		my $sam_entry = $sam_reader->get_next();

		next unless ($sam_entry->is_paired());
		next if ($sam_entry->is_query_unmapped());
		
		my $qname = $sam_entry->get_qname();
		my $refname = $sam_entry->get_rname();
		my $cigar = $sam_entry->get_cigar();

		if ($sam_entry->is_mate_unmapped()){
			$junc{$qname} = 1;
			$num_mapped++;

			my $fromte;

			if ($sam_entry->is_first_in_pair()){
				$fromte = ($lib_type eq "fr") ? 1 : 0;
			}else{
				$fromte = ($lib_type eq "fr") ? 0 : 1;
			}

			print INFO "$qname\t$fromte\t$refname\t$cigar\n";
			
		}		
	}
	close INFO;

	print STDERR "$num_mapped read mapped while its mate not\n";

	print STDERR "Preparing junction reads ...\n";

	my $thread_1 = threads->create('READS::getRead', \%junc, $r1, $junc_r1);
	my $thread_2 = threads->create('READS::getRead', \%junc, $r2, $junc_r2);

	foreach my $thread ($thread_1, $thread_2) {
        $thread->join();
        if (my $error = $thread->error()) {
            print STDERR "Error, thread exited with error $error\n";
        }
    }

    &compress($sam);

    return;
}

sub get_unique_sam {

	my $bam_to_sam_cmd = "samtools view -h -o $tophatout_sam $tophatout_bam";
	&process_cmd($bam_to_sam_cmd) unless (-s $tophatout_sam);

	my %sam_info = ();
	my %read_names = ();
	my %transcribed_strand = ();

	my $sam_reader = new SAM_reader($tophatout_sam);

	while ($sam_reader->has_next()){

		my $sam_entry = $sam_reader->get_next();

		next unless ($sam_entry->is_paired());
		next if ($sam_entry->is_query_unmapped());

		my $readname = $sam_entry->get_read_name();

		if ($read_names{$readname}){
			$read_names{$readname}++;
		}else{
			$read_names{$readname} = 1;
		}

		if ($lib_type){
			$transcribed_strand{$readname} = $sam_entry->get_query_transcribed_strand($lib_type);
		}else{
			$transcribed_strand{$readname} = "+";
		}

		@{$sam_info{$readname}} = $sam_entry->get_fields(); 
	}

	my $unique_mapped_count = 0;

	open (my $fh_plus, ">$unique_plus") or die "Cannot write $unique_plus";
	open (my $fh_minus, ">$unique_minus") or die "Cannot write $unique_minus";

	foreach my $name (map {$_->[0]}
                     sort { ($a->[1] cmp $b->[1])
                            ||
                            ($a->[2] <=> $b->[2])
                    } map {[$_, $sam_info{$_}[2]=~/^chr(.+)$/, $sam_info{$_}[3]]
                    } keys %read_names){

		next unless ($read_names{$name} == 1);

		$unique_mapped_count++;

		my $fh_out = ($transcribed_strand{$name} eq "+") ? $fh_plus : $fh_minus;
		
		print $fh_out join("\t", @{$sam_info{$name}}) . "\n";
	}

	close $fh_plus;
	close $fh_minus;

	open (my $fh_info, ">$unique_sam_info") or die "Cannot write $unique_sam_info";
	print $fh_info "uniquely mapped reads:\t$unique_mapped_count";
	close $fh_info;

	return;
}


################################
#     assemble transcripts     #
################################

sub assemble {

	print "Assemble plus strand ... \n";
	&assemble_each_strand($unique_plus);

	if ($lib_type){
		print "Assemble minus strand ... \n";
		&assemble_each_strand($unique_minus);
	}

	print "Report transcripts ... \n";
	&report_trans($unique_plus, $unique_minus);

    return;
}

sub assemble_each_strand {

	my $sam_file = shift;

    my $frag_coords_file = "$sam_file.frag_coords";
    my $frag_coverage_file = "$sam_file.frag_coverage";
    my $partitions_file = "$sam_file.partitions";
    my $partition_track_file = "$sam_file.track";
    my $merged_partition_file = "$sam_file.merged_partitions";

    &ASSEMBLE::extract_frag_coords($sam_file, $frag_coords_file, $insert_size_min, $insert_size_max) unless (-s $frag_coords_file);

    &ASSEMBLE::write_frag_coverage($frag_coords_file, $frag_coverage_file) unless (-s $frag_coverage_file);
    
    &ASSEMBLE::extract_reads_per_coverage_partition($frag_coverage_file, $partitions_file, $sam_file, $partition_track_file, $min_cov) unless (-s $partition_track_file);

    unless (-s $partition_track_file){
    	print STDERR "\nNo valid partition\n";
    	return;
    }

    &ASSEMBLE::merge_partition($partition_track_file, $merged_partition_file, $min_intron_length, $unique_sam_info, $junc_info) unless (-s $merged_partition_file);

    return;

}

sub report_trans {
	my ($sam_plus, $sam_minus) = @_;

	my $merged_plus_file = "$sam_plus.merged_partitions";
	my $merged_minus_file = "$sam_minus.merged_partitions";

	my %trans = ();

	if (-s $merged_plus_file){
		open (my $plus_fh, $merged_plus_file) or die "Cannot open $merged_plus_file";

		while (<$plus_fh>){
			my ($num, $chr, $start, $end, $cov, $fpkm, $fromte, $refte) = split /\t/;
			chomp $refte;
			my $id = "plus_" . $num;

			@{$trans{$id}} = ($chr, $start, $end, $cov, $fpkm, "+", $fromte, $refte);
		}

		close $plus_fh;
	}

	if ($lib_type){
		if (-s $merged_minus_file){
			open (my $minus_fh, $merged_minus_file) or die "Cannot open $merged_minus_file";

			while (<$minus_fh>){
				my ($num, $chr, $start, $end, $cov, $fpkm, $fromte, $refte) = split /\t/;
				chomp $refte;
				my $id = "minus_" . $num;

				@{$trans{$id}} = ($chr, $start, $end, $cov, $fpkm, "-", $fromte, $refte);

			}

			close $minus_fh;
		}
	}

	# GTF format
	# Fields must be tab-separated. Also, all but the final field in each feature line must contain a value; "empty" columns should be denoted with a '.'

	# seqname - name of the chromosome or scaffold; chromosome names can be given with or without the 'chr' prefix. Important note: the seqname must be one used within Ensembl, i.e. a standard chromosome name or an Ensembl identifier such as a scaffold ID, without any additional content such as species or assembly. See the example GFF output below.
	# source - name of the program that generated this feature, or the data source (database or project name)
	# feature - feature type name, e.g. Gene, Variation, Similarity
	# start - Start position of the feature, with sequence numbering starting at 1.
	# end - End position of the feature, with sequence numbering starting at 1.
	# score - A floating point value.
	# strand - defined as + (forward) or - (reverse).
	# frame - One of '0', '1' or '2'. '0' indicates that the first base of the feature is the first base of a codon, '1' that the second base is the first base of a codon, and so on..
	# attribute - A semicolon-separated list of tag-value pairs, providing additional information about each feature.

	unless (%trans){
		print "No transcripts found!\n";
		return;
	}

	my $count = 0;
	open (my $trans_fh, ">$transcript_file") or die "Cannot write $transcript_file";

	foreach my $key ( map { $_->[0]}
                     sort { (($a->[1] =~ /^\d+$/ && $b->[1] =~ /^\d+$/) ? ($a->[1] <=> $b->[1]) : ($a->[1] cmp $b->[1]))
                            ||
                            ($a->[2] <=> $b->[2])
                            ||
                            ($a->[3] <=> $b->[3])
                    } map { [$_, $trans{$_}[0]=~/^chr(.+)$/, $trans{$_}[1], $trans{$_}[2]]
					} keys %trans){

		$count ++;

		my $name = "tec_" . $count;
		my $chr = $trans{$key}[0];
		my $start = $trans{$key}[1];
		my $end = $trans{$key}[2];
		my $cov = $trans{$key}[3];
		my $fpkm = $trans{$key}[4];
		my $strand = $trans{$key}[5];
		my $fromte = $trans{$key}[6];
		my $refte = $trans{$key}[7];

		print $trans_fh join ("\t", $chr, "TECDetec", "LCT", $start, $end, $fpkm, $strand, ".", "id=$name;cov=$cov;fromte=$fromte;refte=$refte") . "\n";
	}

	close $trans_fh;

	return;
}

################################
#            others            #
################################

sub process_cmd {

	my ($cmd) = @_;

	#print STDERR "CMD: $cmd\n";

	my $ret = system($cmd);

	if ($ret){
		die "Error, command $cmd died with return $ret\n";
	}

	return;
}

sub compress {

	my ($file) = @_;

	my $cmd = "tar -zcvf $file.tgz $file";

	&process_cmd($cmd);
	`rm $file`;

	return;
}





